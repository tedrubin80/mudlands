--
-- PostgreSQL database dump
--

\restrict rplpaVyTtMrQBTbXgZhDontvVJBjjo7ZCiamqtJUzRHXvqkIhsvAGVky1f7sG2V

-- Dumped from database version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: game_logs; Type: TABLE; Schema: public; Owner: mudlands_user
--

CREATE TABLE public.game_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    player_id uuid,
    action character varying(255),
    details jsonb,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.game_logs OWNER TO mudlands_user;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: mudlands_user
--

CREATE TABLE public.inventory (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    player_id uuid,
    item_id character varying(100),
    quantity integer DEFAULT 1,
    equipped boolean DEFAULT false,
    slot character varying(50)
);


ALTER TABLE public.inventory OWNER TO mudlands_user;

--
-- Name: items; Type: TABLE; Schema: public; Owner: mudlands_user
--

CREATE TABLE public.items (
    id character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    type character varying(50),
    rarity character varying(50),
    stats jsonb,
    requirements jsonb,
    value integer DEFAULT 0
);


ALTER TABLE public.items OWNER TO mudlands_user;

--
-- Name: player_stats; Type: TABLE; Schema: public; Owner: mudlands_user
--

CREATE TABLE public.player_stats (
    player_id uuid NOT NULL,
    level integer DEFAULT 1,
    experience integer DEFAULT 0,
    class character varying(50) DEFAULT 'Novice'::character varying,
    str integer DEFAULT 5,
    agi integer DEFAULT 5,
    vit integer DEFAULT 5,
    "int" integer DEFAULT 5,
    dex integer DEFAULT 5,
    luk integer DEFAULT 5,
    stat_points integer DEFAULT 0,
    skill_points integer DEFAULT 0,
    current_hp integer,
    max_hp integer,
    current_mp integer,
    max_mp integer,
    location character varying(100) DEFAULT 'town_square'::character varying
);


ALTER TABLE public.player_stats OWNER TO mudlands_user;

--
-- Name: players; Type: TABLE; Schema: public; Owner: mudlands_user
--

CREATE TABLE public.players (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    is_admin boolean DEFAULT false,
    role_id integer DEFAULT 0
);


ALTER TABLE public.players OWNER TO mudlands_user;

--
-- Name: role_change_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_change_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    player_id uuid,
    old_role_id integer,
    new_role_id integer,
    changed_by uuid,
    reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.role_change_logs OWNER TO postgres;

--
-- Name: rooms; Type: TABLE; Schema: public; Owner: mudlands_user
--

CREATE TABLE public.rooms (
    id character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    exits jsonb,
    properties jsonb
);


ALTER TABLE public.rooms OWNER TO mudlands_user;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    role_name character varying(50) NOT NULL,
    role_level integer NOT NULL,
    description text,
    permissions jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_roles_id_seq OWNER TO postgres;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Data for Name: game_logs; Type: TABLE DATA; Schema: public; Owner: mudlands_user
--

COPY public.game_logs (id, player_id, action, details, "timestamp") FROM stdin;
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: mudlands_user
--

COPY public.inventory (id, player_id, item_id, quantity, equipped, slot) FROM stdin;
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: mudlands_user
--

COPY public.items (id, name, description, type, rarity, stats, requirements, value) FROM stdin;
\.


--
-- Data for Name: player_stats; Type: TABLE DATA; Schema: public; Owner: mudlands_user
--

COPY public.player_stats (player_id, level, experience, class, str, agi, vit, "int", dex, luk, stat_points, skill_points, current_hp, max_hp, current_mp, max_mp, location) FROM stdin;
b9f47c6c-ca7a-4f67-b3fa-4675dd7d1250	1	0	Novice	15	15	15	15	15	15	0	0	270	270	135	135	town_square
145cf246-7fe5-4186-b2f5-69c44749a75c	1	0	Novice	5	5	5	5	5	5	0	0	170	170	85	85	town_square
eb33100a-723d-4228-a970-a18efba760b2	1	0	Novice	10	20	19	10	18	13	0	0	310	310	110	110	town_square
7d893d50-6620-403b-a91b-2d0319f2b09a	1	0	Novice	15	12	13	10	15	25	0	0	250	250	110	110	town_square
69535999-e928-476a-9a35-cd47105341d2	1	0	Novice	10	19	7	34	10	10	0	0	190	190	230	230	market_street
236a5b66-d6ed-4d4d-9011-14b07a33bfd1	1	0	Novice	5	5	5	5	5	5	0	0	170	170	85	85	town_square
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: mudlands_user
--

COPY public.players (id, username, email, password_hash, created_at, last_login, is_admin, role_id) FROM stdin;
b9f47c6c-ca7a-4f67-b3fa-4675dd7d1250	testchar	test@example.com	$2b$10$ucYukVAaEEeF4XjPrN5fFOrg6gh9zNGWUN1lznOOppYpD6ATLvSMK	2025-09-21 18:41:15.443503	2025-09-21 18:41:15.443503	f	0
d908ebf9-6769-4218-88d3-d8caf546e819	testuser_direct	testdirect@example.com	$2b$10$K7L1OJ0TfPO0tBGxJAJpXONv.J9YgJMWu3/98GjJa.M44u8PlWmAu	2025-09-23 15:29:12.049443	\N	f	0
145cf246-7fe5-4186-b2f5-69c44749a75c	testfix_1758643844	testfix_1758643844@example.com	$2b$10$/47dLOYin6MsiEHFjeJ2c.RJjtKFEHi6MPoTNxnezCfEHa3cQEw9e	2025-09-23 16:10:44.646042	2025-09-23 16:10:44.646042	f	0
ba559746-f077-4b1d-b4ed-a2d3ad5ac780	newuser_1758644196	newuser_1758644196@mudlands.com	$2b$10$K7L1OJ0TfPO0tBGxJAJpXONv.J9YgJMWu3/98GjJa.M44u8PlWmAu	2025-09-23 16:16:36.182344	\N	f	0
eb33100a-723d-4228-a970-a18efba760b2	Grim	crtrubin@gmail.com	$2b$10$/OAwfIQaNA3Hh2OHuLRlPOtB7zZ4oOeqcZIjCw5PYQKo5fUf7ATOO	2025-09-24 20:05:31.839393	2025-09-24 20:05:31.839393	f	0
7d893d50-6620-403b-a91b-2d0319f2b09a	TestCharSuccess	testsuccess@example.com	$2b$10$FgNPcpvvu5YeHUB/Yff84eFPvf3w.Id7Or7dHMeGlaVHfhMug.oyy	2025-09-25 02:00:39.398211	2025-09-25 02:00:39.398211	f	0
69535999-e928-476a-9a35-cd47105341d2	mudlands_admin	ted@theorubin.com	$2b$10$zZ.WRiuDxuCs5tBjvN0cYelYBfkovjV3BGTXM6a6MJJxURywmWOne	2025-09-08 01:13:05.232901	2025-09-25 13:35:29.886686	t	3
236a5b66-d6ed-4d4d-9011-14b07a33bfd1	newuser	newuser@example.com	$2b$10$AAR91.KwhrFzaNrXNxOXSOMs/V/Gp0zcZdV.KAyaMV5mhZym/DVlS	2025-09-26 14:46:41.016524	2025-09-26 14:46:41.016524	f	0
\.


--
-- Data for Name: role_change_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_change_logs (id, player_id, old_role_id, new_role_id, changed_by, reason, created_at) FROM stdin;
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: mudlands_user
--

COPY public.rooms (id, name, description, exits, properties) FROM stdin;
town_square	Town Square	The bustling center of town. A large fountain stands in the middle, its crystal-clear water sparkling in the light. Merchants hawk their wares from colorful stalls, and adventurers gather to share tales of their journeys.	{"east": "town_market", "west": "town_inn", "north": "town_north_gate", "south": "town_south_gate"}	{"safe": true, "respawn_point": true}
town_inn	The Sleeping Dragon Inn	A cozy inn with a warm fireplace. The smell of hearty stew fills the air, and weary travelers rest at wooden tables. A staircase leads up to the guest rooms.	{"up": "inn_rooms", "east": "town_square"}	{"heal": true, "safe": true}
inn_rooms	Inn Guest Rooms	A hallway lined with doors to private rooms. Soft snoring can be heard from behind some of them. A window at the end offers a view of the town square below.	{"down": "town_inn"}	{"safe": true}
town_market	Town Market	A busy marketplace filled with vendors selling all manner of goods. The air is filled with the sounds of haggling and the smells of exotic spices and fresh bread.	{"west": "town_square", "north": "market_alley"}	{"safe": true, "shop": true}
market_alley	Market Alley	A narrow alley between market stalls. Shadows dance in the flickering torchlight, and the sounds of the main market echo off the walls.	{"north": "old_warehouse", "south": "town_market"}	{}
old_warehouse	Old Warehouse	A dusty old warehouse filled with crates and barrels. Cobwebs hang from the rafters, and the air smells of age and neglect. This might be a good place to find abandoned treasures.	{"south": "market_alley"}	{"loot_spawn": true}
town_north_gate	North Town Gate	The sturdy north gate of the town. Guards stand watch here, keeping an eye on travelers coming and going. Beyond the gate, a road leads north into the wilderness.	{"north": "forest_entrance", "south": "town_square"}	{"safe": true}
forest_entrance	Forest Entrance	The edge of a dark forest. Ancient trees tower overhead, their branches blocking out most of the sunlight. Strange sounds echo from deep within the woods.	{"east": "forest_clearing", "north": "forest_path", "south": "town_north_gate"}	{"monster_spawn": true}
forest_path	Forest Path	A winding path through the dense forest. Roots and fallen branches make walking treacherous. You can hear the rustling of unseen creatures in the underbrush.	{"east": "spider_lair", "north": "deep_forest", "south": "forest_entrance"}	{"monster_spawn": true}
forest_clearing	Forest Clearing	A peaceful clearing in the forest where sunlight filters through the canopy. Wildflowers grow here, and a small stream babbles nearby.	{"west": "forest_entrance", "north": "hidden_cave"}	{"rest": true}
hidden_cave	Hidden Cave	A mysterious cave hidden behind a curtain of vines. Strange crystals embedded in the walls glow with an otherworldly light. This place feels ancient and magical.	{"south": "forest_clearing"}	{"magical": true, "treasure": true}
spider_lair	Spider Lair	A dark, web-filled lair where giant spiders make their home. Sticky webs hang everywhere, and you can see the wrapped remains of previous victims.	{"west": "forest_path"}	{"boss_room": true, "dangerous": true, "monster_spawn": true}
deep_forest	Deep Forest	The heart of the ancient forest. The trees here are massive and old, their trunks wider than houses. An eerie silence pervades this place.	{"east": "ancient_grove", "south": "forest_path"}	{"rare_spawns": true, "monster_spawn": true}
ancient_grove	Ancient Grove	A sacred grove where druids once performed their rituals. A stone circle stands in the center, covered in mysterious runes. The air hums with residual magic.	{"west": "deep_forest"}	{"sacred": true, "magical": true, "quest_location": true}
town_south_gate	South Town Gate	The southern gate leading out of town. A well-traveled road stretches south toward distant mountains. Merchant caravans often rest here before beginning their journeys.	{"north": "town_square", "south": "crossroads"}	{"safe": true}
crossroads	Crossroads	A junction where several roads meet. A weathered signpost points in different directions, and travelers often stop here to decide their path.	{"east": "river_crossing", "west": "abandoned_farm", "north": "town_south_gate", "south": "mountain_trail"}	{}
mountain_trail	Mountain Trail	A steep trail winding up into the mountains. The air grows thinner here, and the path becomes more treacherous with each step.	{"up": "mountain_peak", "north": "crossroads"}	{"monster_spawn": true}
mountain_peak	Mountain Peak	The summit of the mountain. From here you can see for miles in every direction. A small shrine dedicated to the mountain spirits stands here.	{"down": "mountain_trail"}	{"sacred": true, "treasure": true}
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (id, role_name, role_level, description, permissions, created_at, updated_at) FROM stdin;
1	player	0	Standard game player with basic access	{"chat": true, "game_access": true, "character_management": true}	2025-09-14 17:50:58.41752	2025-09-14 17:50:58.41752
2	tester	1	Beta tester with bug reporting and testing tools access	{"chat": true, "bug_reports": true, "game_access": true, "testing_tools": true, "feedback_system": true, "character_management": true}	2025-09-14 17:50:58.41752	2025-09-14 17:50:58.41752
3	moderator	2	Player moderator with limited administrative powers	{"chat": true, "game_access": true, "kick_players": true, "mute_players": true, "chat_moderation": true, "view_player_logs": true, "player_management": true, "character_management": true}	2025-09-14 17:50:58.41752	2025-09-14 17:50:58.41752
4	admin	3	Game administrator with full system access	{"chat": true, "ai_tools": true, "broadcast": true, "game_access": true, "kick_players": true, "mute_players": true, "game_commands": true, "world_editing": true, "chat_moderation": true, "view_player_logs": true, "player_management": true, "server_management": true, "character_management": true}	2025-09-14 17:50:58.41752	2025-09-14 17:50:58.41752
5	super_admin	4	Super administrator with role management and system configuration access	{"chat": true, "ai_tools": true, "broadcast": true, "game_access": true, "kick_players": true, "mute_players": true, "game_commands": true, "system_config": true, "world_editing": true, "chat_moderation": true, "role_management": true, "view_player_logs": true, "player_management": true, "security_settings": true, "server_management": true, "character_management": true, "user_role_assignment": true}	2025-09-14 17:50:58.41752	2025-09-14 17:50:58.41752
\.


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 5, true);


--
-- Name: game_logs game_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.game_logs
    ADD CONSTRAINT game_logs_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: player_stats player_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT player_stats_pkey PRIMARY KEY (player_id);


--
-- Name: players players_email_key; Type: CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_email_key UNIQUE (email);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: players players_username_key; Type: CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_username_key UNIQUE (username);


--
-- Name: role_change_logs role_change_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_change_logs
    ADD CONSTRAINT role_change_logs_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_role_level_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_level_key UNIQUE (role_level);


--
-- Name: user_roles user_roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_name_key UNIQUE (role_name);


--
-- Name: idx_players_role_id; Type: INDEX; Schema: public; Owner: mudlands_user
--

CREATE INDEX idx_players_role_id ON public.players USING btree (role_id);


--
-- Name: idx_user_roles_level; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_level ON public.user_roles USING btree (role_level);


--
-- Name: game_logs game_logs_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.game_logs
    ADD CONSTRAINT game_logs_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- Name: inventory inventory_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- Name: player_stats player_stats_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT player_stats_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- Name: players players_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mudlands_user
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.user_roles(role_level);


--
-- Name: role_change_logs role_change_logs_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_change_logs
    ADD CONSTRAINT role_change_logs_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: role_change_logs role_change_logs_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_change_logs
    ADD CONSTRAINT role_change_logs_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO mudlands_user;
GRANT ALL ON SCHEMA public TO mudlands;


--
-- Name: TABLE game_logs; Type: ACL; Schema: public; Owner: mudlands_user
--

GRANT ALL ON TABLE public.game_logs TO mudlands;


--
-- Name: TABLE inventory; Type: ACL; Schema: public; Owner: mudlands_user
--

GRANT ALL ON TABLE public.inventory TO mudlands;


--
-- Name: TABLE items; Type: ACL; Schema: public; Owner: mudlands_user
--

GRANT ALL ON TABLE public.items TO mudlands;


--
-- Name: TABLE player_stats; Type: ACL; Schema: public; Owner: mudlands_user
--

GRANT ALL ON TABLE public.player_stats TO mudlands;


--
-- Name: TABLE players; Type: ACL; Schema: public; Owner: mudlands_user
--

GRANT ALL ON TABLE public.players TO mudlands;


--
-- Name: TABLE role_change_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.role_change_logs TO mudlands;


--
-- Name: TABLE rooms; Type: ACL; Schema: public; Owner: mudlands_user
--

GRANT ALL ON TABLE public.rooms TO mudlands;


--
-- Name: TABLE user_roles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_roles TO mudlands;


--
-- Name: SEQUENCE user_roles_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.user_roles_id_seq TO mudlands;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO mudlands;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO mudlands;


--
-- PostgreSQL database dump complete
--

\unrestrict rplpaVyTtMrQBTbXgZhDontvVJBjjo7ZCiamqtJUzRHXvqkIhsvAGVky1f7sG2V

