#!/bin/bash

echo "Starting Docker service..."
echo "Please run: sudo systemctl start docker"
echo "Then verify with: docker info"
echo "Once Docker is running, you can run: ./scripts/install-ai-services.sh"