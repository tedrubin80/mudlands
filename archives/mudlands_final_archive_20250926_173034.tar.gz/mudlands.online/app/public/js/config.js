// MUDlands Online Client Configuration
// Ensures proper FQDN usage and no localhost references

(function() {
    'use strict';
    
    // Detect protocol and hostname from current location
    const protocol = window.location.protocol;
    const hostname = window.location.hostname;
    const port = window.location.port;
    
    // Force production domain if not on localhost (for development)
    const isDevelopment = hostname === 'localhost' || hostname === '127.0.0.1';
    const isProduction = hostname === 'mudlands.online' || hostname.includes('mudlands');
    
    // Configuration object
    window.MudlandsConfig = {
        // API Configuration
        API_BASE_URL: isProduction ? 'https://mudlands.online/api' : `${protocol}//${hostname}:${port || '3000'}/api`,
        
        // WebSocket Configuration
        WS_URL: isProduction ? 'wss://mudlands.online' : `ws://${hostname}:${port || '3000'}`,
        
        // Game Configuration
        GAME_NAME: 'MUDlands Online',
        VERSION: '1.0.0',
        
        // Client Settings
        AUTO_RECONNECT: true,
        RECONNECT_INTERVAL: 5000,
        MAX_RECONNECT_ATTEMPTS: 10,
        
        // Feature Flags
        FEATURES: {
            AI_CONTENT: true,
            SOUND_EFFECTS: true,
            ANIMATIONS: true,
            DEBUG_MODE: isDevelopment
        },
        
        // Rate Limiting (client-side)
        COMMAND_THROTTLE_MS: 100,
        MESSAGE_THROTTLE_MS: 500,
        
        // Session Configuration
        SESSION_TIMEOUT: 30 * 60 * 1000, // 30 minutes
        IDLE_WARNING_TIME: 25 * 60 * 1000, // Warning at 25 minutes
        
        // UI Configuration
        MAX_CHAT_HISTORY: 500,
        MAX_COMBAT_LOG: 100,
        COMMAND_HISTORY_SIZE: 50,
        
        // Security
        ENABLE_CSRF: true,
        SECURE_COOKIES: isProduction,
        
        // Validation
        validateConnection: function() {
            if (isDevelopment) {
                console.log('Running in development mode');
                return true;
            }
            
            if (!isProduction) {
                console.warn('Unexpected hostname:', hostname);
                console.warn('Redirecting to production domain...');
                window.location.href = 'https://mudlands.online';
                return false;
            }
            
            return true;
        },
        
        // Get full API URL
        getApiUrl: function(endpoint) {
            return `${this.API_BASE_URL}${endpoint}`;
        },
        
        // Get WebSocket URL
        getWebSocketUrl: function() {
            return this.WS_URL;
        },
        
        // Check if running in production
        isProduction: function() {
            return isProduction;
        },
        
        // Initialize configuration
        init: function() {
            // Validate we're on the correct domain
            if (!this.validateConnection()) {
                return false;
            }
            
            // Set up CSRF token if needed
            if (this.ENABLE_CSRF) {
                this.fetchCSRFToken();
            }
            
            // Log configuration in debug mode
            if (this.FEATURES.DEBUG_MODE) {
                console.log('MUDlands Config:', {
                    API_BASE_URL: this.API_BASE_URL,
                    WS_URL: this.WS_URL,
                    Production: isProduction,
                    Hostname: hostname
                });
            }
            
            return true;
        },
        
        // Fetch CSRF token
        fetchCSRFToken: async function() {
            try {
                const response = await fetch(this.getApiUrl('/csrf-token'), {
                    credentials: 'include'
                });
                const data = await response.json();
                this.csrfToken = data.token;
                
                // Add to all future requests
                this.setupAxiosInterceptor();
            } catch (error) {
                console.error('Failed to fetch CSRF token:', error);
            }
        },
        
        // Setup Axios interceptor for CSRF
        setupAxiosInterceptor: function() {
            if (window.axios) {
                window.axios.defaults.headers.common['X-CSRF-Token'] = this.csrfToken;
                window.axios.defaults.baseURL = this.API_BASE_URL;
                window.axios.defaults.withCredentials = true;
            }
        },
        
        // Helper to make authenticated API calls
        apiCall: async function(method, endpoint, data = null) {
            const options = {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': this.csrfToken
                },
                credentials: 'include'
            };
            
            if (data && method !== 'GET') {
                options.body = JSON.stringify(data);
            }
            
            const response = await fetch(this.getApiUrl(endpoint), options);
            
            if (!response.ok) {
                throw new Error(`API call failed: ${response.statusText}`);
            }
            
            return response.json();
        }
    };
    
    // Auto-initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            window.MudlandsConfig.init();
        });
    } else {
        window.MudlandsConfig.init();
    }
})();