// World Editor JavaScript
class WorldEditor {
    constructor() {
        this.rooms = new Map();
        this.npcs = new Map();
        this.items = new Map();
        
        this.initializeEventListeners();
        this.updateSessionSummary();
    }

    initializeEventListeners() {
        // Form submissions
        document.getElementById('room-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.createRoom();
        });

        document.getElementById('npc-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.createNPC();
        });

        document.getElementById('item-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.createItem();
        });
    }

    showStatus(message, isError = false) {
        const statusDiv = document.getElementById('status-message');
        statusDiv.className = `status-message ${isError ? 'status-error' : 'status-success'}`;
        statusDiv.textContent = message;
        statusDiv.style.display = 'block';
        
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
    }

    createRoom() {
        const roomData = {
            id: document.getElementById('room-id').value,
            name: document.getElementById('room-name').value,
            description: document.getElementById('room-description').value,
            exits: {},
            properties: {},
            npcs: []
        };

        // Collect exits
        const exitDirections = ['north', 'south', 'east', 'west', 'up', 'down', 'northeast', 'northwest', 'southeast', 'southwest'];
        exitDirections.forEach(direction => {
            const exitValue = document.getElementById(`exit-${direction}`).value.trim();
            if (exitValue) {
                roomData.exits[direction] = exitValue;
            }
        });

        // Collect properties
        const properties = ['safe', 'dark', 'water', 'forest', 'indoor', 'shop'];
        properties.forEach(prop => {
            if (document.getElementById(`prop-${prop}`).checked) {
                roomData.properties[prop] = true;
            }
        });

        // Collect NPCs
        const npcsList = document.getElementById('room-npcs').value.trim();
        if (npcsList) {
            roomData.npcs = npcsList.split(',').map(id => id.trim()).filter(id => id);
        }

        if (this.rooms.has(roomData.id)) {
            this.showStatus(`Room '${roomData.id}' updated successfully!`);
        } else {
            this.showStatus(`Room '${roomData.id}' created successfully!`);
        }

        this.rooms.set(roomData.id, roomData);
        this.updateSessionSummary();
        
        return roomData;
    }

    createNPC() {
        const npcData = {
            id: document.getElementById('npc-id').value,
            name: document.getElementById('npc-name').value,
            title: document.getElementById('npc-title').value || '',
            race: document.getElementById('npc-race').value,
            gender: document.getElementById('npc-gender').value,
            age: document.getElementById('npc-age').value,
            appearance: {
                description: document.getElementById('npc-description').value || 'A typical person.'
            },
            speech: {
                greeting: document.getElementById('npc-greeting').value
            },
            knowledge: {
                topics: document.getElementById('npc-knowledge').value
                    .split(',')
                    .map(topic => topic.trim())
                    .filter(topic => topic)
            },
            location: document.getElementById('npc-location').value,
            mood: 'neutral',
            trust_level: 0
        };

        if (this.npcs.has(npcData.id)) {
            this.showStatus(`NPC '${npcData.id}' updated successfully!`);
        } else {
            this.showStatus(`NPC '${npcData.id}' created successfully!`);
        }

        this.npcs.set(npcData.id, npcData);
        this.updateSessionSummary();
        
        return npcData;
    }

    createItem() {
        const itemData = {
            id: document.getElementById('item-id').value,
            name: document.getElementById('item-name').value,
            description: document.getElementById('item-description').value,
            type: document.getElementById('item-type').value,
            rarity: document.getElementById('item-rarity').value,
            value: parseInt(document.getElementById('item-value').value) || 0,
            stats: {},
            requirements: {},
            tradeable: true,
            stackable: false
        };

        // Collect stats
        const damage = parseInt(document.getElementById('item-damage').value) || 0;
        const defense = parseInt(document.getElementById('item-defense').value) || 0;
        const durability = parseInt(document.getElementById('item-durability').value) || 100;

        if (damage > 0) itemData.stats.damage = damage;
        if (defense > 0) itemData.stats.defense = defense;
        if (durability !== 100) itemData.stats.durability = durability;

        // Set stackable for consumables and materials
        if (['consumable', 'material'].includes(itemData.type)) {
            itemData.stackable = true;
        }

        if (this.items.has(itemData.id)) {
            this.showStatus(`Item '${itemData.id}' updated successfully!`);
        } else {
            this.showStatus(`Item '${itemData.id}' created successfully!`);
        }

        this.items.set(itemData.id, itemData);
        this.updateSessionSummary();
        
        return itemData;
    }

    previewRoom() {
        try {
            const roomData = this.createRoom();
            const preview = document.getElementById('room-preview');
            preview.textContent = JSON.stringify(roomData, null, 2);
            preview.style.display = 'block';
        } catch (error) {
            this.showStatus('Error creating room preview: ' + error.message, true);
        }
    }

    previewNPC() {
        try {
            const npcData = this.createNPC();
            const preview = document.getElementById('npc-preview');
            preview.textContent = JSON.stringify(npcData, null, 2);
            preview.style.display = 'block';
        } catch (error) {
            this.showStatus('Error creating NPC preview: ' + error.message, true);
        }
    }

    previewItem() {
        try {
            const itemData = this.createItem();
            const preview = document.getElementById('item-preview');
            preview.textContent = JSON.stringify(itemData, null, 2);
            preview.style.display = 'block';
        } catch (error) {
            this.showStatus('Error creating item preview: ' + error.message, true);
        }
    }

    clearRoomForm() {
        document.getElementById('room-form').reset();
        document.getElementById('room-preview').style.display = 'none';
    }

    clearNPCForm() {
        document.getElementById('npc-form').reset();
        document.getElementById('npc-preview').style.display = 'none';
    }

    clearItemForm() {
        document.getElementById('item-form').reset();
        document.getElementById('item-preview').style.display = 'none';
    }

    updateSessionSummary() {
        document.getElementById('room-count').textContent = this.rooms.size;
        document.getElementById('npc-count').textContent = this.npcs.size;
        document.getElementById('item-count').textContent = this.items.size;
    }

    exportWorldData() {
        const worldData = {
            metadata: {
                created: new Date().toISOString(),
                version: '1.0.0',
                editor: 'MUDlands World Editor'
            },
            rooms: Array.from(this.rooms.values()),
            npcs: Array.from(this.npcs.values()),
            items: Array.from(this.items.values())
        };

        const dataStr = JSON.stringify(worldData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = `mudlands-world-${new Date().toISOString().split('T')[0]}.json`;
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        this.showStatus(`Exported ${this.rooms.size} rooms, ${this.npcs.size} NPCs, and ${this.items.size} items!`);
    }

    importWorldData() {
        const fileInput = document.getElementById('import-file');
        const file = fileInput.files[0];
        
        if (!file) {
            this.showStatus('Please select a file to import.', true);
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const worldData = JSON.parse(e.target.result);
                
                // Import rooms
                if (worldData.rooms) {
                    worldData.rooms.forEach(room => {
                        this.rooms.set(room.id, room);
                    });
                }
                
                // Import NPCs
                if (worldData.npcs) {
                    worldData.npcs.forEach(npc => {
                        this.npcs.set(npc.id, npc);
                    });
                }
                
                // Import items
                if (worldData.items) {
                    worldData.items.forEach(item => {
                        this.items.set(item.id, item);
                    });
                }
                
                this.updateSessionSummary();
                this.showStatus('World data imported successfully!');
                
            } catch (error) {
                this.showStatus('Error importing world data: ' + error.message, true);
            }
        };
        
        reader.readAsText(file);
    }

    // Generate random room ID
    generateRoomId() {
        const prefixes = ['ancient', 'dark', 'crystal', 'forgotten', 'mystic', 'shadow', 'bright', 'sacred'];
        const types = ['chamber', 'hall', 'grove', 'cavern', 'tower', 'garden', 'library', 'forge'];
        
        const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
        const type = types[Math.floor(Math.random() * types.length)];
        
        return `${prefix}_${type}`;
    }

    // Generate random NPC ID
    generateNPCId() {
        const roles = ['guard', 'merchant', 'mage', 'priest', 'blacksmith', 'innkeeper', 'bard', 'scholar'];
        const names = ['marcus', 'sarah', 'eldric', 'thorn', 'lyanna', 'gareth', 'elena', 'aldric'];
        
        const role = roles[Math.floor(Math.random() * roles.length)];
        const name = names[Math.floor(Math.random() * names.length)];
        
        return `${role}_${name}`;
    }

    // Generate random item ID
    generateItemId() {
        const materials = ['iron', 'steel', 'silver', 'wooden', 'leather', 'crystal', 'ancient', 'mystic'];
        const items = ['sword', 'shield', 'armor', 'staff', 'bow', 'potion', 'scroll', 'ring'];
        
        const material = materials[Math.floor(Math.random() * materials.length)];
        const item = items[Math.floor(Math.random() * items.length)];
        
        return `${material}_${item}`;
    }
}

// Tab switching functionality
function switchTab(tabName) {
    // Hide all panels
    document.querySelectorAll('.editor-panel').forEach(panel => {
        panel.classList.remove('active');
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected panel
    document.getElementById(`${tabName}-panel`).classList.add('active');
    
    // Mark selected tab as active
    event.target.classList.add('active');
}

// Utility functions accessible from HTML
function previewRoom() {
    worldEditor.previewRoom();
}

function previewNPC() {
    worldEditor.previewNPC();
}

function previewItem() {
    worldEditor.previewItem();
}

function clearRoomForm() {
    worldEditor.clearRoomForm();
}

function clearNPCForm() {
    worldEditor.clearNPCForm();
}

function clearItemForm() {
    worldEditor.clearItemForm();
}

function exportWorldData() {
    worldEditor.exportWorldData();
}

function importWorldData() {
    worldEditor.importWorldData();
}

// Quick generation buttons
function generateRandomRoom() {
    document.getElementById('room-id').value = worldEditor.generateRoomId();
}

function generateRandomNPC() {
    document.getElementById('npc-id').value = worldEditor.generateNPCId();
}

function generateRandomItem() {
    document.getElementById('item-id').value = worldEditor.generateItemId();
}

// Initialize the world editor when the page loads
let worldEditor;
document.addEventListener('DOMContentLoaded', () => {
    worldEditor = new WorldEditor();
    console.log('MUDlands World Editor initialized successfully!');
});

// Auto-save functionality
function autoSave() {
    const sessionData = {
        rooms: Array.from(worldEditor.rooms.entries()),
        npcs: Array.from(worldEditor.npcs.entries()),
        items: Array.from(worldEditor.items.entries()),
        timestamp: Date.now()
    };
    
    localStorage.setItem('mudlands-editor-session', JSON.stringify(sessionData));
}

// Load from auto-save
function loadAutoSave() {
    const savedData = localStorage.getItem('mudlands-editor-session');
    if (savedData) {
        try {
            const sessionData = JSON.parse(savedData);
            
            // Restore data
            worldEditor.rooms = new Map(sessionData.rooms);
            worldEditor.npcs = new Map(sessionData.npcs);
            worldEditor.items = new Map(sessionData.items);
            
            worldEditor.updateSessionSummary();
            worldEditor.showStatus('Auto-saved session restored!');
        } catch (error) {
            console.error('Failed to load auto-save data:', error);
        }
    }
}

// Auto-save every 30 seconds
setInterval(() => {
    if (worldEditor && (worldEditor.rooms.size > 0 || worldEditor.npcs.size > 0 || worldEditor.items.size > 0)) {
        autoSave();
    }
}, 30000);

// Load auto-save on page load
window.addEventListener('load', () => {
    setTimeout(loadAutoSave, 1000); // Wait for world editor to initialize
});