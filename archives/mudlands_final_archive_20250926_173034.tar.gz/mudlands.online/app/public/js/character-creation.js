class CharacterCreator {
    constructor() {
        this.currentStep = 1;
        this.characterData = {
            email: '',
            password: '',
            name: '',
            class: 'Novice',
            stats: {
                str: 10,
                agi: 10,
                vit: 10,
                int: 10,
                dex: 10,
                luk: 10
            },
            description: ''
        };
        this.remainingPoints = 30;
        this.minStatValue = 5;
        this.maxStatValue = 50;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.updateDisplay();
        
        // Check if user is already authenticated
        const token = localStorage.getItem('token');
        if (token) {
            this.verifyToken(token);
        }
    }

    async verifyToken(token) {
        try {
            const response = await fetch('/api/auth/verify', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.ok) {
                // User already has a character, redirect to game
                window.location.href = '/';
            }
        } catch (error) {
            // Token invalid, continue with creation
            localStorage.removeItem('token');
        }
    }

    setupEventListeners() {
        // Step navigation
        document.getElementById('step-1-next').addEventListener('click', () => {
            if (this.validateStep1()) {
                this.nextStep();
            }
        });

        document.getElementById('step-2-back').addEventListener('click', () => this.previousStep());
        document.getElementById('step-2-next').addEventListener('click', () => this.nextStep());
        
        document.getElementById('step-3-back').addEventListener('click', () => this.previousStep());
        document.getElementById('step-3-next').addEventListener('click', () => this.nextStep());
        
        document.getElementById('step-4-back').addEventListener('click', () => this.previousStep());
        document.getElementById('create-character').addEventListener('click', () => this.createCharacter());

        // Email validation
        document.getElementById('email').addEventListener('input', (e) => {
            this.characterData.email = e.target.value;
            this.validateEmail();
            this.updateStep1Button();
        });

        // Password validation
        document.getElementById('password').addEventListener('input', (e) => {
            this.characterData.password = e.target.value;
            this.validatePassword();
            this.updateStep1Button();
        });

        // Character name validation
        document.getElementById('char-name').addEventListener('input', (e) => {
            this.characterData.name = e.target.value;
            this.validateName();
            this.updateStep1Button();
        });

        // Class selection
        document.getElementById('char-class').addEventListener('change', (e) => {
            this.characterData.class = e.target.value;
            this.updateClassDescription();
            this.updateStep1Button();
        });

        // Stat controls
        document.querySelectorAll('.stat-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const stat = e.target.dataset.stat;
                const isIncrease = e.target.classList.contains('increase');
                this.adjustStat(stat, isIncrease ? 1 : -1);
            });
        });

        // Description input
        const descInput = document.getElementById('char-description');
        descInput.addEventListener('input', (e) => {
            this.characterData.description = e.target.value;
            this.updateCharCount();
        });

        // Preset buttons
        document.querySelectorAll('.preset-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.applyPreset(e.target.dataset.preset);
            });
        });
    }

    validateStep1() {
        const email = this.characterData.email.trim();
        const password = this.characterData.password;
        const name = this.characterData.name.trim();
        const characterClass = this.characterData.class;
        
        const emailValid = this.validateEmail();
        const passwordValid = this.validatePassword();
        const nameValid = this.validateName();
        
        return emailValid && passwordValid && nameValid && characterClass;
    }

    validateEmail() {
        const email = this.characterData.email.trim();
        
        if (!email) {
            this.showValidation('email-validation', '', false);
            return false;
        }
        
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            this.showValidation('email-validation', 'Please enter a valid email address', false);
            return false;
        }
        
        this.showValidation('email-validation', '✓ Valid email address', true);
        return true;
    }

    validatePassword() {
        const password = this.characterData.password;
        
        if (!password) {
            this.showValidation('password-validation', '', false);
            return false;
        }
        
        if (password.length < 6) {
            this.showValidation('password-validation', 'Password must be at least 6 characters long', false);
            return false;
        }
        
        if (password.length > 128) {
            this.showValidation('password-validation', 'Password must be 128 characters or less', false);
            return false;
        }
        
        this.showValidation('password-validation', '✓ Valid password', true);
        return true;
    }

    validateName() {
        const name = this.characterData.name.trim();
        
        if (!name) {
            this.showValidation('name-validation', '', false);
            return false;
        }
        
        if (name.length < 3) {
            this.showValidation('name-validation', 'Name must be at least 3 characters long', false);
            return false;
        }
        
        if (name.length > 20) {
            this.showValidation('name-validation', 'Name must be 20 characters or less', false);
            return false;
        }
        
        if (!/^[a-zA-Z0-9_-]+$/.test(name)) {
            this.showValidation('name-validation', 'Only letters, numbers, hyphens, and underscores allowed', false);
            return false;
        }
        
        this.showValidation('name-validation', '✓ Valid character name', true);
        return true;
    }

    showValidation(elementId, message, isValid) {
        const element = document.getElementById(elementId);
        element.textContent = message;
        element.className = 'validation-message ' + (isValid ? 'valid' : 'invalid');
    }

    updateStep1Button() {
        const button = document.getElementById('step-1-next');
        const isValid = this.validateStep1();
        button.disabled = !isValid;
    }

    updateClassDescription() {
        const descElement = document.getElementById('class-description');
        const classDescriptions = {
            'Novice': 'A beginning adventurer with balanced stats. Novices have no specialized strengths or weaknesses, making them versatile and easy to develop in any direction. Perfect for new players who want to explore different playstyles.'
        };
        
        const description = classDescriptions[this.characterData.class] || 'Select a class to see its description.';
        descElement.innerHTML = `<p>${description}</p>`;
    }

    nextStep() {
        if (this.currentStep < 4) {
            this.setStep(this.currentStep + 1);
        }
    }

    previousStep() {
        if (this.currentStep > 1) {
            this.setStep(this.currentStep - 1);
        }
    }

    setStep(step) {
        // Hide current step
        document.querySelector(`#step-${this.currentStep}`).classList.remove('active');
        document.querySelector(`.step[data-step="${this.currentStep}"]`).classList.remove('active');
        document.querySelector(`.step[data-step="${this.currentStep}"]`).classList.add('completed');
        
        // Show new step
        this.currentStep = step;
        document.querySelector(`#step-${this.currentStep}`).classList.add('active');
        document.querySelector(`.step[data-step="${this.currentStep}"]`).classList.add('active');
        
        // Update step-specific content
        if (step === 2) {
            this.updateStatDisplay();
        } else if (step === 4) {
            this.updateSummary();
        }
    }

    adjustStat(stat, change) {
        const currentValue = this.characterData.stats[stat];
        const newValue = currentValue + change;
        
        // Check constraints
        if (change > 0 && (this.remainingPoints <= 0 || newValue > this.maxStatValue)) {
            return;
        }
        
        if (change < 0 && newValue < this.minStatValue) {
            return;
        }
        
        // Apply change
        this.characterData.stats[stat] = newValue;
        this.remainingPoints -= change;
        
        this.updateStatDisplay();
    }

    updateStatDisplay() {
        // Update stat values
        for (const stat in this.characterData.stats) {
            document.getElementById(`stat-${stat}`).textContent = this.characterData.stats[stat];
        }
        
        // Update remaining points
        document.getElementById('remaining-points').textContent = this.remainingPoints;
        
        // Update button states
        for (const stat in this.characterData.stats) {
            const increaseBtn = document.querySelector(`.stat-btn.increase[data-stat="${stat}"]`);
            const decreaseBtn = document.querySelector(`.stat-btn.decrease[data-stat="${stat}"]`);
            
            increaseBtn.disabled = this.remainingPoints <= 0 || this.characterData.stats[stat] >= this.maxStatValue;
            decreaseBtn.disabled = this.characterData.stats[stat] <= this.minStatValue;
        }
        
        // Update calculated stats
        this.updateCalculatedStats();
    }

    updateCalculatedStats() {
        const stats = this.characterData.stats;
        const level = 1;
        
        // Calculate HP: Base (100) + Level bonus (20 per level) + VIT bonus (10 per VIT)
        const hp = 100 + (level * 20) + (stats.vit * 10);
        
        // Calculate MP: Base (50) + Level bonus (10 per level) + INT bonus (5 per INT)  
        const mp = 50 + (level * 10) + (stats.int * 5);
        
        // Calculate base damage: STR + weapon bonus (none for now)
        const damage = `${stats.str}-${stats.str + 5}`;
        
        document.getElementById('calc-hp').textContent = hp;
        document.getElementById('calc-mp').textContent = mp;
        document.getElementById('calc-damage').textContent = damage;
    }

    updateCharCount() {
        const current = this.characterData.description.length;
        const max = 500;
        document.getElementById('desc-count').textContent = current;
        
        const countElement = document.getElementById('desc-count').parentElement;
        if (current > max) {
            countElement.style.color = '#ff0000';
        } else if (current > max * 0.8) {
            countElement.style.color = '#ffff00';
        } else {
            countElement.style.color = '#666';
        }
    }

    applyPreset(preset) {
        const presets = {
            warrior: "A battle-hardened warrior with scars from countless fights. Broad shoulders and calloused hands speak of years wielding sword and shield. Despite the rough exterior, determined eyes show an unbreakable spirit.",
            scholar: "A thoughtful individual with ink-stained fingers and keen eyes that miss nothing. Prefers knowledge over combat, but don't mistake scholarly pursuits for weakness - a sharp mind can be deadlier than any blade.",
            rogue: "Moving with practiced stealth and grace, this figure seems to blend with shadows. Quick fingers and quicker wit make them equally at home picking locks or picking pockets. Trust comes hard to one who lives by cunning.",
            mage: "Crackling with barely contained magical energy, this aspiring spellcaster shows natural talent with the arcane arts. Robes may be simple now, but ambition burns bright in eyes that have glimpsed infinite possibilities."
        };
        
        if (presets[preset]) {
            document.getElementById('char-description').value = presets[preset];
            this.characterData.description = presets[preset];
            this.updateCharCount();
        }
    }

    updateSummary() {
        // Basic info
        document.getElementById('summary-name').textContent = this.characterData.name;
        document.getElementById('summary-class').textContent = this.characterData.class;
        
        // Stats
        for (const stat in this.characterData.stats) {
            document.getElementById(`final-${stat}`).textContent = this.characterData.stats[stat];
        }
        
        // Calculated stats
        const stats = this.characterData.stats;
        const hp = 100 + 20 + (stats.vit * 10);
        const mp = 50 + 10 + (stats.int * 5);
        
        document.getElementById('final-hp').textContent = hp;
        document.getElementById('final-mp').textContent = mp;
        
        // Description
        document.getElementById('summary-description').textContent = 
            this.characterData.description || 'No description provided.';
    }

    async createCharacter() {
        try {
            document.getElementById('loading-modal').classList.add('show');
            
            // Get CSRF token first
            const csrfResponse = await fetch('/api/csrf-token', {
                method: 'GET',
                credentials: 'include'
            });
            
            if (!csrfResponse.ok) {
                throw new Error('Failed to get CSRF token');
            }
            
            const csrfData = await csrfResponse.json();
            
            const response = await fetch('/api/character/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfData.csrfToken
                },
                credentials: 'include',
                body: JSON.stringify(this.characterData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Store authentication info
                localStorage.setItem('token', result.token);
                localStorage.setItem('playerId', result.player.id);
                
                // Redirect to game
                window.location.href = '/';
            } else {
                alert(result.message || 'Character creation failed');
            }
        } catch (error) {
            alert('Failed to create character. Please try again.');
            console.error('Character creation error:', error);
        } finally {
            document.getElementById('loading-modal').classList.remove('show');
        }
    }

    updateDisplay() {
        this.updateClassDescription();
        this.updateStatDisplay();
        this.updateCharCount();
    }
}

// Initialize character creator when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.characterCreator = new CharacterCreator();
});