// Game client for MUDlands Online
class MudClient {
    constructor() {
        this.socket = null;
        this.connected = false;
        this.authenticated = false;
        this.player = null;
        this.commandHistory = [];
        this.historyIndex = -1;
        this.currentChannel = 'local';
        
        this.init();
    }

    init() {
        // Initialize connection status as disconnected
        this.updateConnectionStatus(false);
        this.setupEventListeners();
        this.initializeChatSystem();
        this.showAuthModal();
        this.connectToServer();
    }

    connectToServer() {
        // Use the current page's protocol and host for Socket.IO connection
        // This handles both direct access (http://mudlands.online:3000) and proxy access (https://mudlands.online)
        const socketUrl = window.location.origin;
        
        console.log('Connecting to Socket.IO at:', socketUrl);
        console.log('Page protocol:', window.location.protocol);
        console.log('Page host:', window.location.host);
        
        this.socket = io(socketUrl, {
            reconnection: true,
            reconnectionDelay: 1000,
            reconnectionAttempts: 5,
            timeout: 10000,
            forceNew: true,
            transports: ['websocket', 'polling'],
            upgrade: true,
            rememberUpgrade: false
        });

        this.socket.on('connect', () => {
            console.log('Socket.IO connected successfully');
            this.connected = true;
            this.updateConnectionStatus(true);
            this.addMessage('Connected to server', 'system');
        });

        this.socket.on('disconnect', (reason) => {
            console.log('Socket.IO disconnected:', reason);
            this.connected = false;
            this.updateConnectionStatus(false);
            this.addMessage('Disconnected from server', 'error');
        });

        this.socket.on('connect_error', (error) => {
            console.error('Socket.IO connection error:', error);
            this.connected = false;
            this.updateConnectionStatus(false);
            this.addMessage(`Connection error: ${error.message}`, 'error');
        });

        this.socket.on('reconnect', (attemptNumber) => {
            console.log('Socket.IO reconnected after', attemptNumber, 'attempts');
            this.addMessage('Reconnected to server', 'system');
        });

        this.socket.on('reconnect_failed', () => {
            console.error('Socket.IO failed to reconnect');
            this.addMessage('Failed to reconnect to server', 'error');
        });

        this.socket.on('connected', (data) => {
            this.addMessage(data.message, 'system');
        });

        this.socket.on('authenticated', (data) => {
            this.authenticated = true;
            this.player = data.player;
            this.hideAuthModal();
            this.updatePlayerStatus();
            this.clearTerminal();
            this.addMessage(`Welcome back, ${data.player.name}!`, 'system');
        });

        this.socket.on('authError', (data) => {
            alert(data.message);
        });

        this.socket.on('message', (data) => {
            this.addMessage(data.text, data.type || 'game');
        });

        this.socket.on('playerUpdate', (data) => {
            this.updatePlayerStats(data);
        });

        this.socket.on('error', (error) => {
            this.addMessage(`Error: ${error}`, 'error');
        });
    }

    setupEventListeners() {
        // Command input
        const commandInput = document.getElementById('command-input');
        commandInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                this.sendCommand(commandInput.value);
                commandInput.value = '';
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.navigateHistory(-1);
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.navigateHistory(1);
            }
        });

        // Quick action buttons
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.sendCommand(btn.dataset.command);
            });
        });

        // Compass buttons
        document.querySelectorAll('.compass-btn').forEach(btn => {
            if (!btn.disabled) {
                btn.addEventListener('click', () => {
                    this.sendCommand(btn.dataset.command);
                });
            }
        });

        // Channel buttons
        document.querySelectorAll('.channel-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.switchChannel(btn.dataset.channel);
            });
        });

        // Auth form
        const authForm = document.getElementById('auth-form');
        authForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleAuth();
        });

        // Auth toggle
        document.getElementById('auth-toggle').addEventListener('click', () => {
            this.toggleAuthMode();
        });

        // Character creation
        document.getElementById('create-character').addEventListener('click', () => {
            window.location.href = '/character-creation.html';
        });

        // Auth form submission
        document.getElementById('auth-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleAuth();
        });

        // Auth toggle button
        document.getElementById('auth-toggle').addEventListener('click', () => {
            this.toggleAuthMode();
        });

        // Guest login
        document.getElementById('guest-login').addEventListener('click', () => {
            this.loginAsGuest();
        });

        // Keep input focused
        document.addEventListener('click', () => {
            if (!document.getElementById('auth-modal').classList.contains('show')) {
                commandInput.focus();
            }
        });
    }

    sendCommand(command) {
        if (!command.trim()) return;
        
        // Add to history
        this.commandHistory.push(command);
        this.historyIndex = this.commandHistory.length;
        
        // Show command in terminal
        this.addMessage(`> ${command}`, 'input');
        
        // Check for channel shortcuts
        if (command.startsWith('/')) {
            this.handleChannelCommand(command);
            return;
        }
        
        // Send to server
        if (this.authenticated) {
            this.socket.emit('command', { command });
        } else {
            this.addMessage('You must login first', 'error');
        }
    }

    handleChannelCommand(command) {
        const parts = command.split(' ');
        const channel = parts[0].substring(1);
        const message = parts.slice(1).join(' ');
        
        switch(channel) {
            case 'global':
            case 'g':
                this.sendCommand(`yell ${message}`);
                break;
            case 'party':
            case 'p':
                this.sendCommand(`party ${message}`);
                break;
            case 'guild':
            case 'gu':
                this.sendCommand(`guild ${message}`);
                break;
            case 'whisper':
            case 'w':
                this.sendCommand(`whisper ${message}`);
                break;
            default:
                this.sendCommand(`say ${message}`);
        }
    }

    navigateHistory(direction) {
        const commandInput = document.getElementById('command-input');
        
        if (direction === -1 && this.historyIndex > 0) {
            this.historyIndex--;
            commandInput.value = this.commandHistory[this.historyIndex];
        } else if (direction === 1 && this.historyIndex < this.commandHistory.length - 1) {
            this.historyIndex++;
            commandInput.value = this.commandHistory[this.historyIndex];
        } else if (direction === 1 && this.historyIndex === this.commandHistory.length - 1) {
            this.historyIndex = this.commandHistory.length;
            commandInput.value = '';
        }
    }

    addMessage(text, type = 'game') {
        const outputDiv = document.getElementById('output-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        
        // SECURITY FIX: Use safe text processing instead of innerHTML
        this.processColorsSecurely(text, messageDiv);
        
        outputDiv.appendChild(messageDiv);
        
        // Auto-scroll to bottom
        const terminal = document.getElementById('terminal-output');
        terminal.scrollTop = terminal.scrollHeight;
        
        // Limit message history
        while (outputDiv.children.length > 500) {
            outputDiv.removeChild(outputDiv.firstChild);
        }
    }

    // DEPRECATED: Old unsafe method - kept for reference
    processColors(text) {
        // Convert chalk colors to HTML
        return text
            .replace(/\x1b\[31m(.*?)\x1b\[39m/g, '<span style="color:#ff0000">$1</span>')
            .replace(/\x1b\[32m(.*?)\x1b\[39m/g, '<span style="color:#00ff00">$1</span>')
            .replace(/\x1b\[33m(.*?)\x1b\[39m/g, '<span style="color:#ffff00">$1</span>')
            .replace(/\x1b\[34m(.*?)\x1b\[39m/g, '<span style="color:#0000ff">$1</span>')
            .replace(/\x1b\[35m(.*?)\x1b\[39m/g, '<span style="color:#ff00ff">$1</span>')
            .replace(/\x1b\[36m(.*?)\x1b\[39m/g, '<span style="color:#00ffff">$1</span>');
    }

    // SECURITY: New secure method that prevents XSS
    processColorsSecurely(text, container) {
        // Clear container first
        container.innerHTML = '';
        
        // Parse ANSI color codes safely without using innerHTML
        const colorMap = {
            '\x1b[31m': '#ff0000', // red
            '\x1b[32m': '#00ff00', // green  
            '\x1b[33m': '#ffff00', // yellow
            '\x1b[34m': '#0000ff', // blue
            '\x1b[35m': '#ff00ff', // magenta
            '\x1b[36m': '#00ffff', // cyan
            '\x1b[37m': '#ffffff', // white
            '\x1b[90m': '#888888', // gray
            '\x1b[1m': 'bold',     // bold
            '\x1b[3m': 'italic'    // italic
        };
        
        // Split text by ANSI codes while preserving the codes
        const parts = text.split(/(\x1b\[\d+m)/);
        let currentColor = null;
        let currentStyle = null;
        
        for (let i = 0; i < parts.length; i++) {
            const part = parts[i];
            
            if (part.match(/\x1b\[\d+m/)) {
                // This is an ANSI code
                if (part === '\x1b[39m' || part === '\x1b[0m') {
                    // Reset codes
                    currentColor = null;
                    currentStyle = null;
                } else if (colorMap[part]) {
                    if (colorMap[part] === 'bold') {
                        currentStyle = 'bold';
                    } else if (colorMap[part] === 'italic') {
                        currentStyle = 'italic';
                    } else {
                        currentColor = colorMap[part];
                    }
                }
            } else if (part.length > 0) {
                // This is actual text content - sanitize it
                const textNode = document.createTextNode(part);
                
                if (currentColor || currentStyle) {
                    // Create a span with safe styling
                    const span = document.createElement('span');
                    if (currentColor) {
                        span.style.color = currentColor;
                    }
                    if (currentStyle === 'bold') {
                        span.style.fontWeight = 'bold';
                    } else if (currentStyle === 'italic') {
                        span.style.fontStyle = 'italic';
                    }
                    span.appendChild(textNode);
                    container.appendChild(span);
                } else {
                    // No styling, just add text
                    container.appendChild(textNode);
                }
            }
        }
    }

    clearTerminal() {
        document.getElementById('welcome-screen').style.display = 'none';
        document.getElementById('output-messages').innerHTML = '';
    }

    updateConnectionStatus(connected) {
        const status = document.getElementById('connection-status');
        if (connected) {
            status.classList.remove('disconnected');
            status.classList.add('connected');
        } else {
            status.classList.remove('connected');
            status.classList.add('disconnected');
        }
    }

    updatePlayerStatus() {
        if (this.player) {
            document.getElementById('player-name').textContent = this.player.name;
            document.getElementById('player-level').textContent = `Lv. ${this.player.level}`;
        }
    }

    updatePlayerStats(stats) {
        document.getElementById('player-hp').textContent = `HP: ${stats.hp}/${stats.maxHp}`;
        document.getElementById('player-mp').textContent = `MP: ${stats.mp}/${stats.maxMp}`;
        document.getElementById('player-level').textContent = `Lv. ${stats.level}`;
    }

    switchChannel(channel) {
        this.currentChannel = channel;
        document.querySelectorAll('.channel-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.channel === channel) {
                btn.classList.add('active');
            }
        });
    }

    showAuthModal() {
        document.getElementById('auth-modal').classList.add('show');
    }

    hideAuthModal() {
        document.getElementById('auth-modal').classList.remove('show');
        document.getElementById('command-input').focus();
    }

    toggleAuthMode() {
        const title = document.getElementById('auth-title');
        const submitBtn = document.getElementById('auth-submit');
        const toggleBtn = document.getElementById('auth-toggle');
        const emailField = document.getElementById('email');
        
        if (submitBtn.textContent === 'Login') {
            title.textContent = 'Register for MUDlands';
            submitBtn.textContent = 'Register';
            toggleBtn.textContent = 'Login Instead';
            emailField.style.display = 'block';
            emailField.required = true;
        } else {
            title.textContent = 'Login to MUDlands';
            submitBtn.textContent = 'Login';
            toggleBtn.textContent = 'Register Instead';
            emailField.style.display = 'none';
            emailField.required = false;
        }
    }

    async handleAuth() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const email = document.getElementById('email').value;
        const isRegister = document.getElementById('auth-submit').textContent === 'Register';
        
        try {
            // Get CSRF token first with proper cookie handling
            const csrfResponse = await fetch('/api/csrf-token', {
                method: 'GET',
                credentials: 'include' // Ensure cookies are sent and received
            });
            
            if (!csrfResponse.ok) {
                throw new Error(`Failed to fetch CSRF token: ${csrfResponse.status}`);
            }
            
            const csrfData = await csrfResponse.json();
            
            if (!csrfData.success || !csrfData.csrfToken) {
                throw new Error('Invalid CSRF token response');
            }
            
            console.log('Got CSRF token:', csrfData.csrfToken.substring(0, 8) + '...');
            
            const endpoint = isRegister ? '/api/auth/register' : '/api/auth/login';
            const body = isRegister ? { username, password, email } : { username, password };
            
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfData.csrfToken
                },
                credentials: 'include', // Use same session cookies
                body: JSON.stringify(body)
            });
            
            const data = await response.json();
            
            if (data.success) {
                localStorage.setItem('token', data.token);
                localStorage.setItem('playerId', data.player.id);
                
                // Authenticate with socket
                this.socket.emit('authenticate', {
                    token: data.token,
                    playerId: data.player.id
                });
            } else {
                alert(data.message);
            }
        } catch (error) {
            console.error('Auth error:', error);
            alert('Authentication failed: ' + error.message);
        }
    }

    loginAsGuest() {
        const guestId = 'guest-' + Math.random().toString(36).substr(2, 9);
        this.socket.emit('authenticate', {
            playerId: guestId,
            guest: true
        });
    }

    initializeChatSystem() {
        const chatInput = document.getElementById('chat-input');
        const chatSend = document.getElementById('chat-send');
        const chatChannelSelect = document.getElementById('chat-channel-select');
        const chatMessages = document.getElementById('chat-messages');
        const channelButtons = document.querySelectorAll('.channel-btn');

        // Initialize with welcome message
        this.addChatMessage('system', null, 'Welcome to MUDlands chat!');

        // Handle channel button clicks
        channelButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const channel = btn.dataset.channel;
                chatChannelSelect.value = channel;

                // Update active button
                channelButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                // Clear chat and show channel change
                this.addChatMessage('system', null, `Switched to ${channel} channel`);
            });
        });

        // Send chat message
        const sendMessage = () => {
            const message = chatInput.value.trim();
            const channel = chatChannelSelect.value;

            if (message) {
                // Determine the command based on channel
                let command = '';
                switch(channel) {
                    case 'global':
                        command = `yell ${message}`;
                        break;
                    case 'party':
                        command = `party ${message}`;
                        break;
                    case 'guild':
                        command = `guild ${message}`;
                        break;
                    case 'local':
                    default:
                        command = `say ${message}`;
                        break;
                }

                // Send via socket
                this.socket.emit('command', { command });
                chatInput.value = '';
            }
        };

        // Chat send button
        chatSend.addEventListener('click', sendMessage);

        // Enter key in chat input
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                sendMessage();
            }
        });

        // Listen for chat messages from server
        this.socket.on('chat', (data) => {
            this.addChatMessage(data.channel || 'local', data.sender, data.message, data.timestamp);
        });
    }

    addChatMessage(channel, sender, message, timestamp) {
        const chatMessages = document.getElementById('chat-messages');

        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${channel}`;

        // Add timestamp if provided
        if (timestamp) {
            const time = new Date(timestamp);
            const timeStr = time.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
            });
            messageDiv.innerHTML += `<span class="timestamp">[${timeStr}]</span> `;
        }

        // Add channel tag for non-local messages
        if (channel !== 'local' && channel !== 'system') {
            messageDiv.innerHTML += `<span class="channel-tag">[${channel.toUpperCase()}]</span>`;
        }

        // Add sender name
        if (sender) {
            messageDiv.innerHTML += `<span class="username">${sender}:</span> `;
        }

        // Add message text (escape HTML)
        const messageText = document.createElement('span');
        messageText.textContent = message;
        messageDiv.appendChild(messageText);

        chatMessages.appendChild(messageDiv);

        // Auto-scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Limit chat history to 100 messages
        while (chatMessages.children.length > 100) {
            chatMessages.removeChild(chatMessages.firstChild);
        }
    }
}

// Initialize game when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.mudClient = new MudClient();
});